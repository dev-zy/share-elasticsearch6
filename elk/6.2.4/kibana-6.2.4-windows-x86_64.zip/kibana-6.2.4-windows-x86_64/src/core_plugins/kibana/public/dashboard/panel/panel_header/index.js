export { PanelHeaderContainer as PanelHeader } from './panel_header_container';
