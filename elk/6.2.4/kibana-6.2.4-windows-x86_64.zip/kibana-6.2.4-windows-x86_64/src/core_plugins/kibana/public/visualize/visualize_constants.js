export const VisualizeConstants = {
  LANDING_PAGE_PATH: '/visualize',
  WIZARD_STEP_1_PAGE_PATH: '/visualize/new',
  WIZARD_STEP_2_PAGE_PATH: '/visualize/new/configure',
  CREATE_PATH: '/visualize/create',
  EDIT_PATH: '/visualize/edit',
};
