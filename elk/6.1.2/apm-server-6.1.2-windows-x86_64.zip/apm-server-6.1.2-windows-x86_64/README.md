# Welcome to apm-server 6.1.2

Sends events to Elasticsearch or Logstash

## Getting Started

To get started with apm-server, you need to set up Elasticsearch on your localhost first. After that, start apm-server with:

     ./apm-server -c apm-server.yml -e

This will start apm-server and send the data to your Elasticsearch instance. To load the dashboards for apm-server into Kibana, run:

    ./apm-server setup -e

For further steps visit the [Getting started](https://www.elastic.co/guide/en/apm/get-started/master/) guide.

## Documentation

Visit [Elastic.co Docs](https://www.elastic.co/guide/en/apm/server/master/) for the full apm-server documentation.
