export { FieldWildcardProvider } from './field_wildcard';
