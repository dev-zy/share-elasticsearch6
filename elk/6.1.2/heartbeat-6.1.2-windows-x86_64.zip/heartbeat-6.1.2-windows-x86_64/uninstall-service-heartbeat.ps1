# delete service if it exists
if (Get-Service heartbeat -ErrorAction SilentlyContinue) {
  $service = Get-WmiObject -Class Win32_Service -Filter "name='heartbeat'"
  $service.delete()
}
