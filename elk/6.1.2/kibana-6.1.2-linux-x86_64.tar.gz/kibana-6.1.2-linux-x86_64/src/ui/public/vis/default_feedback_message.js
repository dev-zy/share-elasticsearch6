export const defaultFeedbackMessage = `Have feedback? Please create an issue in 
<a href="https://github.com/elastic/kibana/issues/new" rel="noopener noreferrer" target="_blank">GitHub</a>.`;
