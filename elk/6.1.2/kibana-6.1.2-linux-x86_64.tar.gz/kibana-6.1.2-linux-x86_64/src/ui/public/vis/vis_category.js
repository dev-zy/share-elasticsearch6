export const CATEGORY = {
  BASIC: 'basic',
  DATA: 'data',
  MAP: 'map',
  OTHER: 'other',
  TIME: 'time',
  HIDDEN: 'hidden'
};
