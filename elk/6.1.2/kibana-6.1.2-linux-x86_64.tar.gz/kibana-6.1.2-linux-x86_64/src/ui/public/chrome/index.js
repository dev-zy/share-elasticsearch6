import { chrome } from './chrome';

// eslint-disable-next-line @elastic/kibana-custom/no-default-export
export default chrome;
