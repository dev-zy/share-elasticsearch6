export { queryManagerFactory } from './query_manager';
