'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _collapse_button = require('./collapse_button');

Object.defineProperty(exports, 'KuiCollapseButton', {
  enumerable: true,
  get: function get() {
    return _collapse_button.KuiCollapseButton;
  }
});
