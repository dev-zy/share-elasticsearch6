'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _color_picker = require('./color_picker');

Object.defineProperty(exports, 'KuiColorPicker', {
  enumerable: true,
  get: function get() {
    return _color_picker.KuiColorPicker;
  }
});
