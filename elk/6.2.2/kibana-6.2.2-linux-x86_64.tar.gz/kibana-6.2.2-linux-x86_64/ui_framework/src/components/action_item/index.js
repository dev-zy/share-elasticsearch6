'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _action_item = require('./action_item');

Object.defineProperty(exports, 'KuiActionItem', {
  enumerable: true,
  get: function get() {
    return _action_item.KuiActionItem;
  }
});
