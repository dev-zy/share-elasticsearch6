'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _text_input = require('./text_input');

Object.defineProperty(exports, 'KuiTextInput', {
  enumerable: true,
  get: function get() {
    return _text_input.KuiTextInput;
  }
});
