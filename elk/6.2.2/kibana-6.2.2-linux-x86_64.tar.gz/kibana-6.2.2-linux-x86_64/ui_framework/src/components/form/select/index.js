'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _select = require('./select');

Object.defineProperty(exports, 'KuiSelect', {
  enumerable: true,
  get: function get() {
    return _select.KuiSelect;
  }
});
