'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _label = require('./label');

Object.defineProperty(exports, 'KuiLabel', {
  enumerable: true,
  get: function get() {
    return _label.KuiLabel;
  }
});
