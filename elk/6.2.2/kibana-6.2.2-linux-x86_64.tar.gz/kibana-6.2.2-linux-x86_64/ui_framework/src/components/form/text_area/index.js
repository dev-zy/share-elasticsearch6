'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _text_area = require('./text_area');

Object.defineProperty(exports, 'KuiTextArea', {
  enumerable: true,
  get: function get() {
    return _text_area.KuiTextArea;
  }
});
