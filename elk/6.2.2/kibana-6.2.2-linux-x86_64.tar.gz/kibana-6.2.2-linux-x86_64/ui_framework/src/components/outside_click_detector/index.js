'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _outside_click_detector = require('./outside_click_detector');

Object.defineProperty(exports, 'KuiOutsideClickDetector', {
  enumerable: true,
  get: function get() {
    return _outside_click_detector.KuiOutsideClickDetector;
  }
});
