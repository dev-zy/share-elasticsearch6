'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _code_editor = require('./code_editor');

Object.defineProperty(exports, 'KuiCodeEditor', {
  enumerable: true,
  get: function get() {
    return _code_editor.KuiCodeEditor;
  }
});
