'use strict';

module.exports = require('@elastic/numeral');
